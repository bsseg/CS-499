
public class Contact {
	
	/** Contact ID of the Person*/
	private final String contactId; 
	
	/** First Name of the Contact */
	private String firstName; 
	
	/** Last Name of the Contact */
	private String lastName; 
	
	/** Phone number of the Contact */
	private String phone;
	
	/** Address of the Contact */
	private String address; 
	
	// constants for the maximum size of fields. 
	private final int MAX_CHARS_ID = 10;
	private final int MAX_CHARS_FIRSTNAME = 10;
	private final int MAX_CHARS_LASTNAME = 10;
	private final int MAX_CHARS_PHONE = 10;
	private final int MAX_CHARS_ADDRESS = 30;
	
	/**
	 * Constructor to initialize the contact object with all the field values passed through
	 * the parameters of this constructor. All values must be validated to invoke this object. 
	 * 
	 * @param contactId contact id of contact object. 
	 * @param firstName first name of contact object.
	 * @param lastName last name of contact object.
	 * @param phone phone number of contact object.
	 * @param address address of contact object.
	 * @throws IllegalArgumentException exception thrown if any field is invalid. 
	 */
	public Contact(String contactId, String firstName, String lastName, String phone, String address) 
		throws IllegalArgumentException {
		
		// Validate contactId
		if(!validateText(contactId, MAX_CHARS_ID)) {
			throw new IllegalArgumentException("Constructor ERROR: Illegal Contact ID Parameter");
		}
		
		// Validate First Name
		if(!validateText(firstName, MAX_CHARS_FIRSTNAME)) {
			throw new IllegalArgumentException("Constructor ERROR: Illegal First Name Parameter");
		}
		
		// Validate Last Name
		if(!validateText(lastName, MAX_CHARS_LASTNAME)) {
			throw new IllegalArgumentException("Constructor ERROR: Illegal Last Name Parameter");
		}
		
		// Validate Phone Number
		if(!validatePhone(phone, MAX_CHARS_PHONE)) {
			throw new IllegalArgumentException("Constructor ERROR: Illegal Phone Number Parameter");
		}
		
		// Validate Contact
		if(!validateText(address, MAX_CHARS_ADDRESS)) {
			throw new IllegalArgumentException("Constructor ERROR: Illegal address Parameter");
		}
		
		this.contactId = contactId; 
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone; 
		this.address = address; 		
	}
	
	/**
	 * Get the contactId of this Contact object. 
	 *
	 * @return the contactId 
	 */
	public String getContactId() {
		return contactId;
	}

	/**
	 * Get the firstName of this Contact object. 
	 *
	 * @return the firstName 
	 */
	public String getFirstName() {
		return firstName;
	}
	
	/**
	 * Get the lastName of this Contact object. 
	 *
	 * @return the lastName 
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Get the phone of this Contact object. 
	 *
	 * @return the phone 
	 */
	public String getPhone() {
		return phone;
	}
	
	/**
	 * Get the address of this Contact object. 
	 *
	 * @return the address 
	 */
	public String getAddress() {
		return address;
	}
	
	/**
	 * Set the First Name of this Contact Object. 
	 * 
	 * @param firstName to set
	 * @throws IllegalArgumentException thrown if first Name is invalid
	 */
	public void setFirstName(String firstName)  throws IllegalArgumentException {
		
		if(!validateText(firstName, MAX_CHARS_FIRSTNAME)) {
			throw new IllegalArgumentException("setFirstName: Invalid First Name Parameter");
		}
		
		this.firstName = firstName;
	}
	
	/**
	 * Set the last name of this Contact Object. 
	 *
	 * @param lastName the lastName to set
	 * @throws IllegalArgumentException thrown for invalid last name
	 */
	public void setLastName(String lastName)  throws IllegalArgumentException {
		
		if(!validateText(lastName, MAX_CHARS_LASTNAME)) {
			throw new IllegalArgumentException("setLastName: Invalid Last Name Parameter");
		}
		
		this.lastName = lastName;
	}
	
	/**
	 * Set the Phone number of this Contact Object.  
	 *
	 * @param phone the phone to set
	 * @throws IllegalArgumentException thrown for invalid phone number
	 */
	public void setPhone(String phone)  throws IllegalArgumentException {
		
		if(!validatePhone(phone, MAX_CHARS_PHONE)) {
			throw new IllegalArgumentException("setPhone: Invalid Phone Number Parameter");
		}
		
		this.phone = phone;
	}
	
	/**
	 * Set the Address of this Contact Object. 
	 *
	 * @param address the address to set
	 * @throws IllegalArgumentException thrown for invalid parameter
	 */
	public void setAddress(String address) throws IllegalArgumentException {
		
		if(!validateText(address, MAX_CHARS_ADDRESS)) {
			throw new IllegalArgumentException("setAddress: Invalid Address Parameter");
		}
		
		this.address = address;
	}
	
	
	/**
	 * Helper function to validate a given phone number for a specify number of characters. 
	 * The second validation is that, all characters must be digits. 
	 * 
	 * @param key string to be validated. 
	 * @param maxChars is the maximum number of characters key can have
	 * @return true if valid, otherwise return false
	 */
	private boolean validatePhone(String key, int maxChars) {
		try {
			// perform basic requirements of validation
			if(this.validateText(key, maxChars) && key.length() == maxChars) {
				
				// must be only numeric
				Long.parseLong(key);   
				
				// validated
				return true; 
			}
		} catch(NumberFormatException e) {
			return false; 
		}
		
		return false; 
	}
	
	/**
	 * Helper function to validate a given text for a specify number of characters. 
	 * 
	 * @param key string to be validated. 
	 * @param maxChars is the maximum number of characters key can have
	 * @return true if valid, otherwise return false
	 */
	private boolean validateText(String key, int maxChars) {
		return (key != null) && !key.isEmpty() && key.length() <= maxChars; 
	}
	
}
