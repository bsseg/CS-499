package contact;

public class ContactServiceTest {



import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import main.ContactService;

class ContactServiceTest {
	private ContactService contactService;
	@BeforeEach
	void setUp() {
		contactService = new ContactService();
		assertTrue(contactService.getContactList().isEmpty());}
	@Test
	@DisplayName("Add Content: Empty ArrayList")
	void testAddEmpty() {
		contactService.addContact("Brad", "Bucher","7777799999", "1600 S Eads St");
		assertTrue(contactService.getContactList().get(0).getiD().equals("1"));}
	@Test
	@DisplayName("Add Content: Populated ArrayList")void testAddNotPopulated() {
		contactService.addContact("Brad", "Bucher","7777799999", "1600 S Eads St");
		contactService.addContact("John", "Doe", "7894561230","4458 Poe St");
		assertFalse(contactService.getContactList().isEmpty());
		assertTrue(contactService.getContactList().get(1).getiD().equals("2"));}
	@Test
	@DisplayName("Delete Content")
	void testDelete() {contactService.addContact("Brad", "Bucher","7777799999", "1600 S Eads St");
	contactService.deleteContact("1");
	assertTrue(contactService.getContactList().isEmpty());}
	
	@Test
	@DisplayName("Update Content: First Name")
	void testUpdateFirstName() {
		contactService.addContact("Brad", "Bucher","7777799999", "1600 S Eads St");
		contactService.updateFirstName("1", "Brad");
		assertTrue(contactService.getContactList().get(0).getFirstName().equals("Brad"));}
	@Test
	@DisplayName("Update Content: Last Name")void testUpdateLastName() {
		contactService.addContact("Brad", "Bucher","7777799999", "1600 S Eads St");
		contactService.updateLastName("1", "Doe");
		assertTrue(contactService.getContactList().get(0).getLastName().equals("Doe"));}
	@Test
	@DisplayName("Update Content: Phone")
	void testUpdatePhone() {
		contactService.addContact("Brad", "Bucher","7777799999", "1600 S Eads St");
		contactService.updatePhone("1", "7777799999");
		assertTrue(contactService.getContactList().get(0).getPhone().equals("7777799999"));}
	@Test
	@DisplayName("Update Content: Address"
			)void testUpdateAddress() {
		contactService.addContact("Brad", "Bucher","7777799999", "1600 S Eads St");
		contactService.updateAddress("1", "4458 Poe St");
		assertTrue(contactService.getContactList().get(0).getAddress().equals("4458 Poe St"));
	}
	}
