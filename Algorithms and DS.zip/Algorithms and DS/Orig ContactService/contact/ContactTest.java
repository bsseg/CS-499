package contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class ContactTest {

	
	//Test ID
	@Test
	@DisplayName("ID: Too long")
	void testContactIDTooLong() {
		
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("12345678910", "Brad", "Bucher","7777799999", "1600 S Eads St");});}
	@Test
	@DisplayName("ID: Null")
	void testContactIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact(null, "Brad", "Bucher", "7777799999","1600 S Eads St");});}
	@Test
	@DisplayName("ID: Non-Numeric")
	void testContactIDNonNumeric() {
		Contact contact = new Contact("1", "Brad", "Bucher","7777799999", "1600 S Eads St");
		Assertions.assertThrows(NumberFormatException.class,() -> {
			contact.setiD("a");});
		Assertions.assertThrows(NumberFormatException.class,() -> {
			new Contact("a", "Brad", "Bucher", "7777799999","1600 S Eads St");;});}
	//Test First Name
	@Test
	@DisplayName("First Name: Too Long")void testContactFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("11", "Bradtvtvtvtv", "Bucher","7777799999", "1600 S Eads St");});}
	@Test
	@DisplayName("First Name: Too Short")
	void testContactFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("11", null, "Bucher", "7777799999","1600 S Eads St");});}
	//Test Last Name
	@Test
	@DisplayName("Last Name: Too Long")void testContactLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("11", "Brad", "Buchertvtvtv","7777799999", "1600 S Eads St");});}
	@Test
	@DisplayName("Last Name: Null")void testContactLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("11", "Brad", null, "7777799999","1600 S Eads St");});}
	//Test Phone Number
	@Test
	@DisplayName("Phone: Too Long")void testContactPhoneTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("11", "Brad", "Bucher","777777999999", "1600 S Eads St");});}
	@Test
	@DisplayName("Phone: Too Short")void testContactPhoneTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("11", "Brad", "Bucher", "77779999","1600 S Eads St");});}
	@Test
	@DisplayName("Phone: Null")void testContactPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("11", "Brad", "Bucher", null, "1600 SEads St");});}
	//Test Address
	@Test
	@DisplayName("Address: Too Long")void testContactAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("11", "Brad", "Bucher", "7777799999","1600 S Eads Sttvtvtvttvtvtvtvtvtvt");});}
	@Test
	@DisplayName("Address: Null")void testContactAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			new Contact("11", "Brad", "Bucher", "7777799999",null);});
		}

}


