package contact;

public class Contact {
	private String iD;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	public Contact(String iD, String firstName, String lastName,String phone, String address){
		//Data validation: Throws NumberFormatException if IDis not a number
		Integer.parseInt(iD);
		if (iD == null || iD.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
			}
		if (firstName == null || firstName.length() > 10) 
		{
			throw new IllegalArgumentException("Invalid firstname");
			}
		if (lastName == null || lastName.length() > 10) 
		{
			throw new IllegalArgumentException("Invalid lastname");
			}
		if (phone == null || phone.length() != 10) 
		{
			throw new IllegalArgumentException("Invalid phonenumber");
			}
		if (address == null || address.length() > 30) 
		{
			throw new IllegalArgumentException("Invalidaddress");
			}
		this.iD = iD;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
		}
	public String getiD() {
		return iD;
		}
	public void setiD(String iD) {
		//Data validation: Throws NumberFormatException if IDis not a number
		Integer.parseInt(iD);
		if (iD == null || iD.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
			}
		this.iD = iD;}
	public String getFirstName() {
		return firstName;
		}
	public void setFirstName(String firstName) {
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid firstname");
			}
		this.firstName = firstName;
		}
	public String getLastName() {
		return lastName;
		}
	public void setLastName(String lastName) {
		if (lastName == null || lastName.length() > 10) 
		{
			throw new IllegalArgumentException("Invalid lastname");
			}
		this.lastName = lastName;
		}
	public String getPhone() {
		return phone;
		}
	public void setPhone(String phone) {
		if (phone == null || phone.length() != 10) 
		{
			throw new IllegalArgumentException("Invalid phonenumber");
			}
		this.phone = phone;
		}
	public String getAddress() {
		return address;
		}
	public void setAddress(String address) {if (address == null || address.length() > 30) 
	{
		throw new IllegalArgumentException("Invalidaddress");
		}
	this.address = address;
	}
}
		